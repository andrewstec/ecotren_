# SQL SERVER ACCOUNT #
* username: ecotrend_admin
* password: ecotrend123
# FTP ACCOUNT #
* username: ecotrend_admin
* password: ecotrend123
* host: ecotrendproject.ahui09.com
# EMAIL ACCOUNT #
* email: ecotrend.noreply@ahui09.com
* password: ecotrend123